from locust import HttpUser, task, between
import random
import json
import time


class WebsiteUser(HttpUser):
    wait_time = between(1, 2)  # Simulates user think time between actions
    host = "https://bcfgbot.com"  # Base URL for your hosted chatbot

    def on_start(self):
        """
        Simulates a user logging in to the chatbot.
        """
        self.nickname = f"User{random.randint(1, 1000)}"
        self.user_id = f"UID{random.randint(1, 100000)}"
        self.session_token = None
        self.login()

    def login(self):
        """
        Simulates user login.
        """
        response = self.client.post(
            "/api/chat/login/",
            json={"nickname": self.nickname, "user_id": self.user_id},
            headers={"Content-Type": "application/json"},
        )
        if response.status_code == 200:
            data = response.json()
            if data.get("status") == "success":
                self.session_token = self.user_id
                print(f"Logged in as {self.nickname}")
            else:
                print(f"Login failed: {data.get('error')}")
        else:
            print(
                f"Login request failed with status code: {response.status_code}, Response: {response.text}"
            )

    @task
    def have_conversation(self):
        """
        Simulates a sequential conversation with the bot.
        User sends two messages and waits for the bot's response each time.
        """
        if not self.session_token:
            print("Session token missing. Skipping conversation.")
            return

        for i in range(2):  # Simulate two messages
            user_message = f"Test message {i+1}"
            response = self.client.post(
                "/api/chat/send/",
                json={"message": user_message},
                headers={
                    "Content-Type": "application/json",
                    "X-User-Id": self.session_token,
                },
            )
            if response.status_code == 200:
                bot_response = response.json().get("response", "No response")
                print(f"Bot response: {bot_response}")
            else:
                print(
                    f"Failed to send message {i+1} with status code: {response.status_code}, Response: {response.text}"
                )
            # Wait for a second before sending the next message
            time.sleep(1)

        # Stop this user after completing the conversation
        self.stop()
